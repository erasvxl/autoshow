from django.contrib import admin
from .models import Car, Supplier, SupplyOrder

admin.site.register(Car)
admin.site.register(Supplier)
admin.site.register(SupplyOrder)
